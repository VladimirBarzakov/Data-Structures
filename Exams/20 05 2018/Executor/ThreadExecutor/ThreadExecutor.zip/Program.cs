﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

public class Program
{
    static void Main(string[] args)
    {
        
    }
}

